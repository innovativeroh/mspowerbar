<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
<style type='text/css'>
* {
    font-family: 'Poppins', sans-serif;
    box-sizing: border-box;
    font-weight: 400;
}
    </style>
<div style='height: 151px; width: 360px; border: 3px solid #000;'>
    <div style='display: flex; flex-direction: row;'>
        <div style='flex: 4; height: 151px; border-right: 3px solid #000;'>
        
        </div>
        <div style='flex: 6;'>
            <div style='display: flex; flex-direction: row; height: 40px;'>
                <div style='flex: 5; border-right: 3px solid #000; border-bottom: 3px solid #000; padding: 7px;'>
                <p style='            -webkit-transform: rotate(-90deg); 
            -moz-transform: rotate(-90deg);    
            transform:rotate(-90deg);
            filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=3);'>Size</p>
               </div>
                <div style='flex: 5; border-bottom: 3px solid #000; padding: 7px;'>
                s
                </div>
            </div>
            <div style='display: flex; flex-direction: row; height: 111px;'>
                <div style='flex: 5; border-right: 3px solid #000;'>
                s
               </div>
                <div style='flex: 5;'>
                s
                </div>
            </div>
        </div>

    </div>
</div>