<div class="az-content pd-y-20 pd-lg-y-30 pd-xl-y-40">
      <div class="container">
        <div class="az-content-left az-content-left-components">
          <div class="component-item">
            <label>SIDEBAR</label>
            <nav class="nav flex-column">
              <a href="dm-manager.php" class="nav-link">Create DM</a>
              <a href="#" class="nav-link">List DM</a>
              <hr></hr>
              <a href="design-numbers.php" class="nav-link">List Design Number</a>
              <a href="add-design-number.php" class="nav-link">Add Design Number</a>
              <hr></hr>
              
            </nav>
</div>
        </div><!-- az-content-left -->